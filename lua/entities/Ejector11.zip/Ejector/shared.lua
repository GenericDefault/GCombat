 ENT.Type = "anim"  
 ENT.Base = "base_gmodentity"     
 ENT.PrintName		= "Ejector"  
 ENT.Author			= "Q42"  
 ENT.Contact			= "FrigginRatBomb@gmail.com"  
 ENT.Purpose			= "Eject"  
 ENT.Instructions	= "GTFO exploding boat!"  
 
ENT.Spawnable			= true
ENT.AdminSpawnable		= false
ENT.exploding			= true

